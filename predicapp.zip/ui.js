const UI = {
  DAYS: ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'],
  TIMES: ['07:00-09:00','09:00-11:00','11:00-13:00','13:00-15:00','15:00-17:00','17:00-19:00'],
  
  getFullDay: (d) => {
    const m = {Lun:'Lunes',Mar:'Martes',Mié:'Miércoles',Jue:'Jueves',Vie:'Viernes',Sáb:'Sábado',Dom:'Domingo'};
    return m[d];
  },

  renderBoard: (slots) => {
    const tbody = document.getElementById('table-body');
    const cards = document.getElementById('mobile-cards');
    tbody.innerHTML = ''; cards.innerHTML = '';
    let parti = 0, full = 0;

    UI.TIMES.forEach(t => {
      // Desktop
      const tr = document.createElement('tr');
      tr.innerHTML = `<td><strong>${t}</strong></td>`;
      
      UI.DAYS.forEach(d => {
        const slot = slots[d]?.find(s => s.time === t);
        if (!slot) return;
        const isFull = slot.reservations.length >= 2;
        if (isFull) full++; else if (slot.reservations.length === 1) parti++;
        slot.status = isFull ? 'full' : (slot.reservations.length === 1 ? 'partial' : 'free');

        const td = document.createElement('td');
        td.className = `slot-cell ${slot.status}`;
        if (slot.reservations.length > 0) {
          td.innerHTML = slot.reservations.map(r => 
            `<span>${r.name.split(' ')[0]}</span> <button onclick="UI.deleteRes('${d}','${t}','${r.name}')" aria-label="Eliminar reserva de ${r.name}">❌</button>`
          ).join('<br>');
        } else {
          td.textContent = '➕';
        }
        td.onclick = (e) => {
          if(e.target.tagName !== 'BUTTON') window.openReserve(d, slot);
        };
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    });

    // Mobile
    UI.DAYS.forEach(d => {
      const header = document.createElement('div');
      header.className = 'mobile-day-header';
      header.textContent = UI.getFullDay(d);
      header.style.cssText = "font-weight:bold;margin:10px 0 5px;font-family:Merriweather;color:#1a3a5c;";
      cards.appendChild(header);
      slots[d].forEach(sl => {
        const c = document.createElement('div');
        c.className = 'slot-card';
        c.innerHTML = `<span>${sl.time}</span> <span class="dot ${sl.status}"></span> <button class="btn-reserve" ${sl.status==='full'?'disabled':''}>${sl.status==='full'?'Completo':'Reservar'}</button>`;
        c.querySelector('.btn-reserve').onclick = () => window.openReserve(d, sl);
        cards.appendChild(c);
      });
    });

    document.getElementById('count-parti').textContent = parti;
    document.getElementById('count-comp').textContent = full;
  },

  deleteRes: (d, t, n) => {
    if(confirm(`¿Eliminar reserva de ${n}?`)) {
      window.removeReservation(d, t, n);
    }
  }
};