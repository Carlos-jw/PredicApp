document.addEventListener('DOMContentLoaded', () => {
  DB.init();
  const state = {
    slots: DB.getObj('slots'),
    points: DB.get('points'),
    participants: DB.get('participants'),
    currentSlot: null
  };

  UI.renderBoard(state.slots);
  document.getElementById('count-part').textContent = state.participants.length;
  document.getElementById('count-point').textContent = state.points.length;

  // Focus Management y Accesibilidad
  const modals = document.querySelectorAll('dialog');
  const openBtns = document.querySelectorAll('[data-view="reserve"], [data-view="people"]');
  
  modals.forEach(m => {
    const closeBtn = m.querySelector('.close-btn, .close-modal');
    if(closeBtn) closeBtn.onclick = () => m.close();
  });

  // Navegación
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.nav-tab').forEach(t => t.setAttribute('aria-selected', 'false'));
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      
      if(tab.dataset.view === 'reserve') document.getElementById('modal-reserve').showModal();
      if(tab.dataset.view === 'people') document.getElementById('modal-participant').showModal();
      if(tab.dataset.view === 'admin') document.getElementById('modal-admin').showModal();
    };
  });

  // Lógica de Reserva Global
  window.openReserve = (d, sl) => {
    if(sl.status === 'full') return;
    state.currentSlot = { d, sl };
    const sel = document.getElementById('sel-participant');
    sel.innerHTML = '<option value="">Selecciona tu nombre</option>';
    state.participants.forEach(p => sel.innerHTML += `<option value="${p.name}">${p.name}</option>`);
    
    const selP = document.getElementById('sel-point');
    selP.innerHTML = '<option value="">Selecciona un punto</option>';
    state.points.forEach(p => selP.innerHTML += `<option value="${p}">${p}</option>`);
    
    document.getElementById('res-info').value = `${UI.getFullDay(d)} - ${sl.time}`;
    document.getElementById('modal-reserve').showModal();  };

  // Validación y Envío de Reserva
  document.getElementById('form-reserve').onsubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById('sel-participant').value;
    const point = document.getElementById('sel-point').value;
    const errDiv = document.getElementById('error-reserve');
    
    if(!name || !point) {
      errDiv.textContent = '⚠️ Completa todos los campos';
      return;
    }
    
    // Validación duplicados
    if(state.participants.some(p => p.name === name)) {
       // Lógica para evitar duplicados o confirmar
    }

    const { d, sl } = state.currentSlot;
    sl.reservations.push({ name, point });
    sl.status = sl.reservations.length >= 2 ? 'full' : 'partial';
    
    DB.setObj('slots', state.slots);
    DB.log(`Reserva: ${name} en ${d}`);
    UI.renderBoard(state.slots);
    document.getElementById('modal-reserve').close();
    errDiv.textContent = '';
    e.target.reset();
  };

  // Lógica de Participantes
  document.getElementById('form-participant').onsubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById('inp-part-name').value.trim();
    const errDiv = document.getElementById('error-part');
    
    if(!name) { errDiv.textContent = '⚠️ El nombre es obligatorio'; return; }
    if(state.participants.some(p => p.name.toLowerCase() === name.toLowerCase())) {
      errDiv.textContent = '⚠️ Ya existe un participante con ese nombre';
      return;
    }

    state.participants.push({ name, phone: document.getElementById('inp-part-phone').value });
    DB.set('participants', state.participants);
    document.getElementById('count-part').textContent = state.participants.length;
    document.getElementById('modal-participant').close();
    errDiv.textContent = '';
    e.target.reset();
  };
  // Panel Admin
  document.getElementById('btn-admin-login').onclick = () => {
    const pass = prompt('🔐 Contraseña (admin):');
    if(pass === 'admin') {
      document.getElementById('tab-admin').style.display = 'block';
      document.getElementById('role-badge').style.display = 'inline';
      renderAdminList();
      document.getElementById('modal-admin').showModal();
    }
  };

  document.getElementById('btn-add-point').onclick = () => {
    const p = prompt('Nombre del punto:');
    if(p && !state.points.includes(p)) {
      state.points.push(p);
      DB.set('points', state.points);
      renderAdminList();
    }
  };

  function renderAdminList() {
    document.getElementById('list-points').innerHTML = state.points.map((p,i) => 
      `<li>${p} <button onclick="deletePoint(${i})" aria-label="Eliminar punto">❌</button></li>`
    ).join('');
    document.getElementById('list-parts').innerHTML = state.participants.map((p,i) => 
      `<li>${p.name} <button onclick="deletePart(${i})" aria-label="Eliminar participante">❌</button></li>`
    ).join('');
    document.getElementById('audit-log').innerHTML = DB.get('audit').slice(-10).reverse().map(a => `<div>🕒 ${a}</div>`).join('');
  }

  // Funciones Globales para eliminar
  window.removeReservation = (d, t, n) => {
    const sl = state.slots[d].find(s => s.time === t);
    if(sl) {
      sl.reservations = sl.reservations.filter(r => r.name !== n);
      sl.status = sl.reservations.length >= 2 ? 'full' : (sl.reservations.length ? 'partial' : 'free');
      DB.setObj('slots', state.slots);
      UI.renderBoard(state.slots);
      DB.log(`Cancelación: ${n}`);
    }
  };

  window.deletePart = (i) => {
    if(confirm('¿Eliminar participante?')) {
      state.participants.splice(i, 1);
      DB.set('participants', state.participants);
      renderAdminList();
    }
  };
  window.deletePoint = (i) => {
    if(confirm('¿Eliminar punto?')) {
      state.points.splice(i, 1);
      DB.set('points', state.points);
      renderAdminList();
    }
  };

  // Onboarding
  window.nextObStep = () => {
    const slides = document.querySelectorAll('.ob-slide');
    const dots = document.querySelectorAll('.dot-ind');
    let active = [...slides].findIndex(s => s.style.display !== 'none');
    slides[active].style.display = 'none';
    dots[active].classList.remove('active');
    if(slides[active+1]) {
      slides[active+1].style.display = 'block';
      dots[active+1].classList.add('active');
    }
  };
  window.finishOb = () => {
    document.getElementById('onboarding-overlay').style.display = 'none';
    localStorage.setItem('predicapp_onboarded', 'true');
  };
  
  if(!localStorage.getItem('predicapp_onboarded')) {
    document.getElementById('onboarding-overlay').style.display = 'flex';
  }
});